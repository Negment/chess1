// 画面の動作確認: 起動 → Stockfishの状態 → 手の入力 → 最適解 → ルールの切り替え
const { test, expect } = require("@playwright/test");

test.beforeEach(async ({ page }) => {
  page.errors = [];
  page.on("pageerror", (e) => page.errors.push(String(e)));
  await page.goto("/");
});

test("画面が開き、JavaScriptのエラーが出ない", async ({ page }) => {
  await expect(page.locator(".tabs button[data-t=ana]")).toBeVisible();
  await expect(page.locator(".tabs button[data-t=set]")).toBeVisible();
  expect(page.errors).toEqual([]);
});

test("Stockfishの状態が、準備完了か失敗のどちらかに落ち着く", async ({ page }) => {
  // 読み込みには時間がかかるので、「起動中…」が消えるのを待つ
  await expect(page.locator("#sfSt")).not.toContainText("起動中", { timeout: 150000 });
  const text = await page.locator("#sfSt").textContent();
  expect(text).toMatch(/準備完了|起動できませんでした/);
});

test("手を入力して、最適解が出る", async ({ page }) => {
  await page.locator(".tabs button[data-t=ana]").click();
  await page.locator("#mv").fill("1. e4 e5 2. Nf3 Nc6 3. Bb5");
  await page.locator("#mvGo").click();
  await page.locator("#autoGo").click();
  await expect(page.locator("#autoRes")).toContainText("最適解", { timeout: 150000 });
  expect(page.errors).toEqual([]);
});

test("ルールのチェックを切り替えても、エラーが出ない", async ({ page }) => {
  await page.locator(".tabs button[data-t=set]").click();
  const castle = page.locator("#ruleCastle");
  await castle.uncheck();
  await castle.check();
  expect(page.errors).toEqual([]);
});
